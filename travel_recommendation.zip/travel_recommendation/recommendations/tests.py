# recommendations/tests.py

from django.test import TestCase

class YourModelTestCase(TestCase):
    def test_example(self):
        # 示例测试
        self.assertEqual(1 + 1, 2)
