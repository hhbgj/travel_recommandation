
from django.shortcuts import render
from django.http import JsonResponse
from .models import Attraction

def index(request):
    # 渲染主页
    return render(request, 'recommendations/index.html')

def recommend(request):
    if request.method == "POST":
        # 从 POST 请求中获取目的地名称
        destination_name = request.POST.get("destination")

        # 确保目的地名称有效
        if destination_name:
            # 查询与目的地相关的景点，并转换为列表
            attractions = list(Attraction.objects.filter(destination__name=destination_name).values())
            return JsonResponse(attractions, safe=False)

    # 如果请求方法不是 POST 或者目的地名称无效，返回空列表
    return JsonResponse([], safe=False)
