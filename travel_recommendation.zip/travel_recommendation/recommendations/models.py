from django.db import models

class Destination(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Attraction(models.Model):
    name = models.CharField(max_length=100)
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE)
    description = models.TextField()
    rating = models.FloatField()
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    destination = models.ForeignKey('Destination', on_delete=models.CASCADE)

    def __str__(self):
        return self.name
