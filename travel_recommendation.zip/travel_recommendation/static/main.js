document.getElementById('destination-form').addEventListener('submit', function(e) {
    e.preventDefault();
    let destination = this.destination.value;

    fetch('/recommend/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': getCookie('csrftoken') // 获取 CSRF Token
        },
        body: new URLSearchParams({ 'destination': destination })
    })
    .then(response => {
        if (!response.ok) { // 检查响应状态
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        displayRecommendations(data);
        getGeocode(destination, data);
    })
    .catch(error => {
        console.error('请求错误:', error);
    });
});

function displayRecommendations(attractions) {
    const recommendationsDiv = document.getElementById('recommendations');
    recommendationsDiv.innerHTML = '<h2>推荐景点:</h2>';
    attractions.forEach((attraction, index) => {
        recommendationsDiv.innerHTML += `<p>${index + 1}. ${attraction.name} - ${attraction.description} (评分: ${attraction.rating})</p>`;
    });
}

function getGeocode(address, attractions) {
    const apiKey = '32365002072541eace2333845d72aa13'; // 高德地图API密钥
    const url = `https://restapi.amap.com/v3/geocode/geo?address=${encodeURIComponent(address)}&key=${apiKey}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.status === '1' && data.geocodes.length > 0) {
                const location = data.geocodes[0].location.split(',');
                const longitude = parseFloat(location[0]);
                const latitude = parseFloat(location[1]);
                initMap(longitude, latitude, attractions);
            } else {
                console.error('地理编码失败:', data);
            }
        })
        .catch(error => console.error('请求错误:', error));
}

function initMap(longitude, latitude, attractions) {
    const map = new AMap.Map('map', {
        zoom: 10,
        center: [longitude, latitude] // 设置地图中心为获取到的经纬度
    });

    // 清除之前的标记
    map.clearMap();

    const markerIconUrl = 'https://img.icons8.com/ios-filled/50/000000/marker.png'; // 自定义图标URL

    attractions.forEach((attraction, index) => {
        const marker = new AMap.Marker({
            position: [attraction.longitude, attraction.latitude], // 使用每个景点的经纬度
            title: `${index + 1}. ${attraction.name}`, // 将序号添加到标记标题中
            icon: markerIconUrl // 设置自定义图标
        });
        marker.setMap(map);
    });

    // 将第一个景点的坐标作为地图的中心
    if (attractions.length > 0) {
        const firstAttraction = attractions[0];
        map.setCenter([firstAttraction.longitude, firstAttraction.latitude]);
    }
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
