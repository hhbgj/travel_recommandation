document.getElementById('destination-form').addEventListener('submit', function(e) {
    e.preventDefault();
    let destination = this.destination.value;

    fetch('/recommend/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: new URLSearchParams({ 'destination': destination })
    })
    .then(response => response.json())
    .then(data => {
        displayRecommendations(data);
        getGeocode(destination, data);
    });
});

function displayRecommendations(attractions) {
    const recommendationsDiv = document.getElementById('recommendations');
    recommendationsDiv.innerHTML = '<h2>推荐景点:</h2>';
    attractions.forEach((attraction, index) => {
        recommendationsDiv.innerHTML += `<p>${index + 1}. ${attraction.name} - ${attraction.description} (评分: ${attraction.rating})</p>`;
    });
}

function getGeocode(address, attractions) {
    const apiKey = '32365002072541eace2333845d72aa13';
    const url = `https://restapi.amap.com/v3/geocode/geo?address=${encodeURIComponent(address)}&key=${apiKey}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.status === '1' && data.geocodes.length > 0) {
                const location = data.geocodes[0].location.split(',');
                const longitude = parseFloat(location[0]);
                const latitude = parseFloat(location[1]);
                initMap(longitude, latitude, attractions);
            } else {
                console.error('地理编码失败:', data);
            }
        })
        .catch(error => console.error('请求错误:', error));
}

function initMap(longitude, latitude, attractions) {
    const map = new AMap.Map('map', {
        zoom: 10,
        center: [longitude, latitude] // 设置地图中心为获取到的经纬度
    });

    // 清除之前的标记
    map.clearMap();

    attractions.forEach((attraction, index) => {
        const marker = new AMap.Marker({
            position: [attraction.longitude, attraction.latitude], // 使用每个景点的经纬度
            title: `${index + 1}. ${attraction.name}` // 将序号添加到标记标题中
        });
        marker.setMap(map);

        // 在标记上方添加序号
        const label = new AMap.Label({
            content: `${index + 1}`, // 序号
            offset: new AMap.Pixel(0, -20), // 调整位置
            draggable: false,
            position: marker.getPosition()
        });
        label.setMap(map);
    });

    // 将第一个景点的坐标作为地图的中心
    if (attractions.length > 0) {
        const firstAttraction = attractions[0];
        map.setCenter([firstAttraction.longitude, firstAttraction.latitude]);
    }
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
